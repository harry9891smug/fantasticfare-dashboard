'use client'
export default function EarningsChart() {



  return (
  
                            <div className="card o-hidden ">
                                <div className="card-header">

                                    <div className="card-header-title">
                                        <h4>Earning </h4>
                                    </div>
                                    <div className="card-body p-0">
                                        <div id="bar-chart-earning"></div>
                                    </div>

                                </div>
                            </div>
            
  )
}