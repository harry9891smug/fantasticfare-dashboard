'use client'
import 'react-datepicker/dist/react-datepicker.css'

export default function CalendarWidget() {

  return (
                            <div className="datepicker-dashboard">
                                <div className="datepicker-here" data-language="en"></div>
                            </div>
                    
  )
}